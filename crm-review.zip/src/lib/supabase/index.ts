import { createClient } from './client';

export { createClient };
export const supabase = createClient();
