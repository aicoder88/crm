#!/bin/bash

# Quick database status check

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Purrify CRM - Database Status"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

node scripts/verify-database.mjs

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Commands:"
echo "  ./scripts/execute-sql.sh      - Apply migration"
echo "  node scripts/verify-database.mjs - Verify database"
echo "  cat MIGRATION_GUIDE.md         - Read migration guide"
echo ""
